<?php

add_action( 'woocommerce_before_checkout_form', 'init_check_cart_item_stock' );

function init_check_cart_item_stock(){ 
    


define('CFG_SERVICE_INSTANCEKEY', '9e060d6f-44fc-4864-9078-0ad08b14e99d');
define('CFG_REQUEST_LANGUAGE', 'en');
define('CFG_SESSIONID', '');
define('CFG_BLOCKLIST', '');
define('CFG_FRAMESIZE', '20'); 

function getvariationarray($des){
    $text=stristr($des,"{");
    $text2=strip_tags($text);
    $json_arr = json_decode($text2, true);
    return $json_arr;
}

function getitemid($des){
$taobao=strpos($des,"taobao.com");
$a1688=strpos($des,"1688.com");

if($taobao!==false){
    $start = 'item/';
    $end = '.htm';
    $startpos = strpos($des, $start) + strlen($start);
    if (strpos($des, $start) !== false) {
        $endpos = strpos($des, $end, $startpos);
    if (strpos($des, $end, $startpos) !== false) {
        $itemid=substr($des, $startpos, $endpos - $startpos);
        return $itemid;
    }
    }
 }
else if($a1688!==false){
    $start = 'offer/';
    $end = '.htm';
 
    $startpos = strpos($des, $start) + strlen($start);
    if (strpos($des, $start) !== false) {
        $endpos = strpos($des, $end, $startpos);
    if (strpos($des, $end, $startpos) !== false) {
        $itemid=substr($des, $startpos, $endpos - $startpos);
        return 'abb-'.$itemid;
    }
    }
}
else{
   return "";
}

}

function getstockavailablity($cartarr, $actualarr){
    $stockavail=true;
    $cart_arr=$cartarr;
    $actual_arr=$actualarr; 
    
    
    foreach ($cart_arr['att'] as $key=>$value){
        foreach ($actual_arr as $keyy =>$valuee){
           $qtyarry=array_diff_assoc($valuee, $value);
           if (array_key_exists("qty",$qtyarry) && sizeof($qtyarry)==1){
              $qty_original=$qtyarry['qty']; 
           }
            $qtyarry2=array_diff_assoc($value, $valuee);
           if (array_key_exists("qty",$qtyarry2) && sizeof($qtyarry2)==1){
               $qty_cart= $qtyarry2['qty'];
           }
           
           if($qty_original>$qty_cart){
               $stockavail=true;
           }
           else{
               $stockavail=false;
              
           }

         }
    }
    
    return $stockavail;
    
   // echo $cart_arr['att'][0]['colour'];
    //echo $actual_arr[0]['colour'];
}



function getitemstockavailablearray($itemId){


$link = 'http://otapi.net/OtapiWebService2.asmx/GetItemFullInfoWithPromotions?instanceKey=' . CFG_SERVICE_INSTANCEKEY
        . '&language=' . CFG_REQUEST_LANGUAGE
        . '&itemId=' . $itemId;
        
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $link);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_HEADER, 0);
 
$result = curl_exec($curl);
if ($result === FALSE) {
    echo "cURL Error: " . curl_error($curl); die();
}
$xmlObject = simplexml_load_string($result);

$json = json_encode($xmlObject);
$data = json_decode($json,true);
 
curl_close($curl);
 
if ((string)$xmlObject->ErrorCode !== 'Ok') {

   echo "Error: " . $xmlObject->ErrorDescription; die();
}
$product_attributes = $data['OtapiItemFullInfo']['Attributes']['ItemAttribute'];
$MasterQuantity=$data['OtapiItemFullInfo']['MasterQuantity'];
$ConfiguredItems=$data['OtapiItemFullInfo']['ConfiguredItems']['OtapiConfiguredItem'];
$arr=array();

if($ConfiguredItems!="" || $ConfiguredItems!=NULL )
{
    
    foreach($ConfiguredItems as $ci){
    //echo $ci['Quantity'];
    // [0]
    //$txt='';
    $newarr=array();
    foreach($ci['Configurators']['ValuedConfigurator'] as $cic){
           
             if($cic['@attributes'])
             {
             $Ppid=$cic['@attributes']['Pid'];     
             $Vvid=$cic['@attributes']['Vid'];
             }
            else{
             $Ppid=$cic['Pid'];     
             $Vvid=$cic['Vid'];
             }
             
             //[0]
             
        
        foreach($product_attributes as $pa){


            if($pa['@attributes'])
             {
             $Pid=$pa['@attributes']['Pid'];     
             $Vid=$pa['@attributes']['Vid'];
             $PropertyName=$pa['PropertyName']; 
             $Value=$pa['Value']; 

             }
            else{
             $Pid=$pa['Pid'];     
             $Vid=$pa['Vid'];
             $PropertyName=$pa['PropertyName']; 
             $Value=$pa['Value'];
             }
   
             
             //[0]
             if(($Ppid==$Pid) && ($Vvid==$Vid)){
                //$txt=$txt.$PropertyName.':'.$Value.',';
                 //$arr2[$PropertyName][$Value];
                 $newarr[$PropertyName]=$Value;
              
             }
             else{
                //array_push($arr,1);  
             }
             
 
            
        }
      //echo $cic['Pid'];
      
    }
 
  // $txt=$txt.'quantity:'.$ci['Quantity'];
   $newarr['qty']=$ci['Quantity'];
   array_push($arr,$newarr); 
    //array_push($arr,"Quantity:".$ci['Quantity']); ;
    //array_push($arr,"break"); 
}
    
}
else{
    array_push($arr,$MasterQuantity);
}

 return $arr;
}


function getcartitems()
    {
 global $woocommerce;
    $items = $woocommerce->cart->get_cart();
    
  //print_r($items);
  
   
        foreach($items as $item => $values) { 
            $_product =  wc_get_product( $values['data']->get_id()); 
           //echo $item;
            //$product_id=$values['data']->get_id();
            $qty_in_cart=$values['quantity'];
            $desc= $_product->get_description();
            $cartitemvararray=getvariationarray($desc);
            
            $itemid=getitemid($desc);
            
            if($itemid!=""){
                
                
                 $actualitemvararray=getitemstockavailablearray($itemid);
           

           if(sizeof($cartitemvararray['att'])==0){
              $stockcount=$actualitemvararray[0]; 
              
              if($stockcount>$qty_in_cart){
                 $isstock=true; 
              }
              else{
                  $isstock=false;
              }
           }
           
           else{
               
               $isstock=getstockavailablity($cartitemvararray, $actualitemvararray); 
           }
           
    
          
           if(!$isstock){
               WC()->cart->remove_cart_item($item);
               wp_redirect( 'https://borderlesscommerce.net/cart/' );
               exit;
               
           }
                
            }
          
        
        }  
    }

getcartitems();

}  // end init_check_cart_item_stock