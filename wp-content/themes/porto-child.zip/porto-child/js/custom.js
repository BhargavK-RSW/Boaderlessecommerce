
    
$(document).ready(function(){
    
 $('#billing_country option:contains(China)').remove();
 $('#shipping_country option:not(:contains(China))').remove();
 
// $("#billing_country option[value='CN']").remove();

});




